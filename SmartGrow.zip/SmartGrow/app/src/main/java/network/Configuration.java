package network;

public class Configuration {

    public static final String CPS_ADDRESS = "10.0.0.21";
    public static final int CPS_PORT = 3010;
}