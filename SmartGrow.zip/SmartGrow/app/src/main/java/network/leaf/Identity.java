package network.leaf;

public enum Identity {
    PLANT_ENDPOINT,
    ANDROID_USER
}