**Plant Endpoint**
==

The **Plant Endpoint** system is set of components responsible for extracting and delivering sensory information to the central processing server.