**The Database**
===

The SmartGrow requires persistent storage of information to deliver services such as:

* Automated corrective actions based on sensory feedback, such as water a plant when it's too dry.
* User profile creation based on the android phone's MAC address.
* Sensory information over time.

The chosen SQL client is **postgres**. 
