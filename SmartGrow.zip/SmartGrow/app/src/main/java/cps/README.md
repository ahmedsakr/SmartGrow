**Central Processing Server**
==

The **C**entral **P**rocessing **S**erver (CPS) is responsible for bringing the whole SmartGrow system to a smooth state. It will be responsible for managing the different plant endpoints and for providing users through the android application the relevant data.